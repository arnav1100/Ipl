# 🏏 IPL Live API — Session Prediction Engine

A Node.js + Express backend that provides **real-time IPL live scores** and **smart session predictions** (Stake-style YES/NO markets) using scraped cricket data.

---

## 📁 Folder Structure

```
ipl-live-api/
├── src/
│   ├── server.js                    ← Entry point
│   ├── routes/
│   │   ├── live.js                  ← /live route
│   │   └── session.js               ← /session routes
│   ├── controllers/
│   │   ├── liveController.js        ← Live score logic
│   │   └── sessionController.js     ← Session prediction logic
│   └── services/
│       ├── cricketService.js        ← Data fetching (scraping + fallbacks)
│       ├── cacheService.js          ← In-memory cache + auto-refresh
│       └── predictionEngine.js      ← Smart prediction math
├── public/
│   └── index.html                   ← Frontend dashboard (auto-served)
├── .env.example
├── .gitignore
├── package.json
└── README.md
```

---

## ⚡ Quick Start

### 1. Install dependencies
```bash
cd ipl-live-api
npm install
```

### 2. (Optional) Configure environment
```bash
cp .env.example .env
# Edit .env if you want to change port or refresh interval
```

### 3. Start the server
```bash
# Production
npm start

# Development (auto-restart on file change)
npm run dev
```

### 4. Open in browser
```
http://localhost:3000          → Live Dashboard (frontend)
http://localhost:3000/live     → JSON live score
http://localhost:3000/session  → Single prediction (default: powerplay 50 runs)
http://localhost:3000/session/all   → All predictions grouped
http://localhost:3000/session/list  → Catalog of all session types
http://localhost:3000/health   → Health check
```

---

## 📡 API Reference

### `GET /live`
Returns live match score with run rate, overs, phase.

```json
{
  "success": true,
  "source": "sanwebinfo",
  "simulated": false,
  "match": {
    "title": "MI vs CSK · IPL 2025",
    "team1": "Mumbai Indians",
    "team2": "Chennai Super Kings"
  },
  "innings": {
    "score": "68/2",
    "runs": 68,
    "wickets": 2,
    "overs": "7.4",
    "runRate": 8.87,
    "phase": "Middle Overs"
  }
}
```

---

### `GET /session?id=pp_50`
Returns prediction for a specific session.

```json
{
  "success": true,
  "prediction": {
    "id": "pp_50",
    "session": "50 runs in first 6 overs",
    "line": 50,
    "unit": "runs",
    "targetOver": 6,
    "prediction": "YES",
    "confidence": "78%",
    "reason": "38/1 in 4.2 ov · RR 8.86 · Projected ~53 vs line 50 ↑"
  }
}
```

#### Available session IDs:
| ID | Session | Line |
|---|---|---|
| `pp_50` | Powerplay Runs | 50 runs in 6 ov |
| `pp_60` | Powerplay Runs | 60 runs in 6 ov |
| `ov10_80` | 10-over score | 80 runs |
| `ov10_100` | 10-over score | 100 runs |
| `ov15_120` | 15-over score | 120 runs |
| `ov20_160` | Full innings | 160 runs |
| `ov20_175` | Full innings | 175 runs |
| `pp_wkts_2` | PP wickets | 2 wickets |
| `ov20_wkts_6` | Full innings wickets | 6 wickets |
| `ov1_runs` | 1st over | 8 runs |
| `death_54` | Death overs | 54 runs |

---

### `GET /session/all`
Returns all predictions grouped by phase with summary.

```json
{
  "success": true,
  "summary": {
    "totalSessions": 11,
    "activeSessions": 8,
    "yesCount": 5,
    "noCount": 3,
    "avgConfidence": "72%"
  },
  "sessions": {
    "Powerplay": [...],
    "Mid-game": [...],
    "Death Overs": [...],
    "Wickets": [...]
  }
}
```

---

## 🧠 How Prediction Logic Works

The engine uses **real match data** (not random numbers):

```
projected_runs = current_run_rate × overs_remaining
                 + current_runs
                 ± smart_adjustments
```

**Smart Adjustments applied:**
- 🏏 Wicket penalty — each wicket above 2 reduces projected RR by 0.18
- ⚡ Powerplay boost — first 3 overs tend to be aggressive (+0.4 RR)
- 💀 Death overs boost — pinch hitters accelerate (+0.6 RR)
- 📈 High RR momentum — sustained aggression if RR > 9.5
- 📉 Low RR drag — bowlers dominating if RR < 6 after over 3
- ⏱ Time certainty — confidence increases as target over approaches

**Confidence formula:**
```
rawConfidence = 50% + (projectedMargin / line × 30%)
               - wicket_uncertainty
               + time_elapsed_boost
```
Clamped between 28–96%.

---

## 🔄 Data Sources (tried in order)

1. **Sanwebinfo Cricket API** — primary scraping source  
   (GitHub: `sanwebinfo/cricket-api` — public Vercel/Workers deployment)
2. **CricAPI free tier** — backup
3. **Realistic simulation** — always available as final fallback (clearly labelled)

---

## 🚀 Deploy to Render (Free)

### Step 1 — Push to GitHub
```bash
git init
git add .
git commit -m "IPL Live API initial commit"
git remote add origin https://github.com/YOUR_USERNAME/ipl-live-api.git
git push -u origin main
```

### Step 2 — Create Render Web Service
1. Go to [render.com](https://render.com) → New → Web Service
2. Connect your GitHub repo
3. Fill in settings:
   - **Environment**: Node
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
4. Add Environment Variables:
   - `PORT` = `10000` (Render uses 10000)
5. Click **Deploy**

Your API will be live at: `https://your-app-name.onrender.com`

### Step 3 — Keep it awake (free tier sleeps after 15min)
Use [UptimeRobot](https://uptimerobot.com) to ping `/health` every 5 minutes.

---

## 🛠 Adding New Session Types

Open `src/services/predictionEngine.js` and add to the `SESSION_TYPES` array:

```js
{
  id: 'ov5_40',
  label: '40 runs by 5th over',
  group: 'Powerplay',
  targetOver: 5,
  line: 40,
  unit: 'runs',
  describe: () => '40 runs in 5 overs',
},
```

That's it — the prediction engine and all endpoints pick it up automatically.

---

## 📦 Dependencies

| Package | Purpose |
|---|---|
| `express` | HTTP server + routing |
| `axios` | HTTP client for scraping |
| `cors` | Cross-origin support |
| `cheerio` | HTML parsing (available if needed for scraping) |
| `nodemon` | Dev auto-restart |

---

## ⚠️ Disclaimer

> Session predictions are statistical estimates based on real match data.  
> They are NOT guaranteed outcomes. For entertainment / educational purposes only.
