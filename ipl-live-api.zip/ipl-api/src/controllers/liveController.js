// ─────────────────────────────────────────────
//  src/controllers/liveController.js
// ─────────────────────────────────────────────
const { getCachedData, forceRefresh } = require('../services/cacheService');

// GET /live
async function getLive(req, res) {
  try {
    let cached = getCachedData();

    // If cache is empty or older than 30s, force a fresh fetch
    if (!cached.data || cached.ageSeconds > 30) {
      cached = await forceRefresh();
    }

    if (!cached.data) {
      return res.status(503).json({
        success: false,
        error:   'Live data unavailable — all sources failed',
        fetchedAt: cached.fetchedAt,
      });
    }

    const d = cached.data;

    return res.json({
      success:   true,
      fetchedAt: cached.fetchedAt,
      ageSeconds: cached.ageSeconds,
      source:    d.source,
      simulated: d.simulated || false,
      match: {
        title:    d.match,
        status:   d.status,
        venue:    d.venue,
        team1:    d.team1,
        team2:    d.team2,
      },
      innings: {
        score:    d.score,
        runs:     d.runs,
        wickets:  d.wickets,
        overs:    d.overs,
        runRate:  d.runRate,
        phase:    getPhase(parseFloat(d.overs)),
      },
    });
  } catch (err) {
    console.error('[liveController]', err.message);
    return res.status(500).json({ success: false, error: err.message });
  }
}

function getPhase(overs) {
  if (overs <= 6)  return 'Powerplay';
  if (overs <= 15) return 'Middle Overs';
  return 'Death Overs';
}

module.exports = { getLive };
