// ─────────────────────────────────────────────
//  src/controllers/sessionController.js
// ─────────────────────────────────────────────
const { getCachedData, forceRefresh } = require('../services/cacheService');
const { predictOne, predictAll, getSessionList } = require('../services/predictionEngine');

// ── Shared helper to get match data (with auto-refresh if stale) ──
async function getMatchData() {
  let cached = getCachedData();
  if (!cached.data || cached.ageSeconds > 30) {
    cached = await forceRefresh();
  }
  return cached;
}

// ─────────────────────────────────────────────
//  GET /session
//  Returns a single session prediction.
//  Query params:
//    ?id=pp_50          → specific session by id
//    (no param)         → first session (pp_50)
// ─────────────────────────────────────────────
async function getSession(req, res) {
  try {
    const cached = await getMatchData();
    const sessionId = req.query.id || 'pp_50';

    if (!cached.data) {
      return res.status(503).json({ success: false, error: 'No live data available' });
    }

    const result = predictOne(sessionId, cached.data);

    if (result.error) {
      return res.status(400).json({ success: false, ...result });
    }

    return res.json({
      success:   true,
      fetchedAt: cached.fetchedAt,
      ageSeconds: cached.ageSeconds,
      match: {
        title:   cached.data.match,
        score:   cached.data.score,
        overs:   cached.data.overs,
        runRate: cached.data.runRate,
      },
      prediction: formatPrediction(result),
    });
  } catch (err) {
    console.error('[sessionController.getSession]', err.message);
    return res.status(500).json({ success: false, error: err.message });
  }
}

// ─────────────────────────────────────────────
//  GET /session/all
//  Returns ALL session predictions at once, grouped by phase.
// ─────────────────────────────────────────────
async function getAllSessions(req, res) {
  try {
    const cached = await getMatchData();

    if (!cached.data) {
      return res.status(503).json({ success: false, error: 'No live data available' });
    }

    const allResults = predictAll(cached.data);

    // Group by group label
    const grouped = {};
    allResults.forEach((r) => {
      if (!grouped[r.group]) grouped[r.group] = [];
      grouped[r.group].push(formatPrediction(r));
    });

    // Summary stats
    const active  = allResults.filter((r) => !r.settled);
    const yesCnt  = active.filter((r) => r.prediction === 'YES').length;
    const noCnt   = active.filter((r) => r.prediction === 'NO').length;
    const avgConf = active.length
      ? Math.round(active.reduce((s, r) => s + (r.confidenceNum || 50), 0) / active.length)
      : 0;

    return res.json({
      success:   true,
      fetchedAt: cached.fetchedAt,
      ageSeconds: cached.ageSeconds,
      source:    cached.data.source,
      simulated: cached.data.simulated || false,
      match: {
        title:    cached.data.match,
        score:    cached.data.score,
        overs:    cached.data.overs,
        wickets:  cached.data.wickets,
        runRate:  cached.data.runRate,
        status:   cached.data.status,
      },
      summary: {
        totalSessions: allResults.length,
        activeSessions: active.length,
        yesCount:  yesCnt,
        noCount:   noCnt,
        avgConfidence: `${avgConf}%`,
      },
      sessions: grouped,
    });
  } catch (err) {
    console.error('[sessionController.getAllSessions]', err.message);
    return res.status(500).json({ success: false, error: err.message });
  }
}

// ─────────────────────────────────────────────
//  GET /session/list
//  Returns all available session types (no prediction, just catalog)
// ─────────────────────────────────────────────
function listSessions(req, res) {
  return res.json({
    success:  true,
    sessions: getSessionList(),
    tip:      'Use /session?id=<session_id> for a specific prediction',
  });
}

// ─────────────────────────────────────────────
//  Format helper — clean output shape
// ─────────────────────────────────────────────
function formatPrediction(r) {
  if (r.settled) {
    return {
      id:        r.id,
      session:   r.session,
      label:     r.label,
      group:     r.group,
      line:      r.line,
      unit:      r.unit,
      targetOver: r.targetOver,
      status:    'SETTLED',
      prediction: null,
      confidence: null,
      reason:    `Over ${r.targetOver} already completed (current: ${r.currentOvers})`,
    };
  }
  return {
    id:          r.id,
    session:     r.session,
    label:       r.label,
    group:       r.group,
    line:        r.line,
    unit:        r.unit,
    targetOver:  r.targetOver,
    status:      'ACTIVE',
    prediction:  r.prediction,
    confidence:  r.confidence,
    reason:      r.reason,
  };
}

module.exports = { getSession, getAllSessions, listSessions };
