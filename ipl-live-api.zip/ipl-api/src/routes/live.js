// ─────────────────────────────────────────────
//  src/routes/live.js
// ─────────────────────────────────────────────
const express = require('express');
const router  = express.Router();
const { getLive } = require('../controllers/liveController');

// GET /live
router.get('/', getLive);

module.exports = router;
