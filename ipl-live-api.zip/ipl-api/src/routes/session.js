// ─────────────────────────────────────────────
//  src/routes/session.js
// ─────────────────────────────────────────────
const express = require('express');
const router  = express.Router();
const {
  getSession,
  getAllSessions,
  listSessions,
} = require('../controllers/sessionController');

// GET /session           → single prediction (default: pp_50)
router.get('/', getSession);

// GET /session/all       → all predictions grouped by phase
router.get('/all', getAllSessions);

// GET /session/list      → catalog of available session types
router.get('/list', listSessions);

module.exports = router;
