// ─────────────────────────────────────────────
//  src/server.js  —  Entry point
// ─────────────────────────────────────────────
const express = require('express');
const cors    = require('cors');
const path    = require('path');

const liveRoutes    = require('./routes/live');
const sessionRoutes = require('./routes/session');
const { startAutoRefresh } = require('./services/cacheService');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Middleware ──
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// ── Routes ──
app.use('/live',    liveRoutes);
app.use('/session', sessionRoutes);

// ── Health check ──
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// ── Root → serve frontend ──
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// ── 404 handler ──
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// ── Global error handler ──
app.use((err, req, res, next) => {
  console.error('[Server Error]', err.message);
  res.status(500).json({ error: 'Internal server error', detail: err.message });
});

// ── Start server + auto-refresh cache ──
app.listen(PORT, () => {
  console.log(`\n🏏  IPL Live API running on http://localhost:${PORT}`);
  console.log(`📊  Endpoints:`);
  console.log(`    GET /live            → Live match score`);
  console.log(`    GET /session         → Single session prediction`);
  console.log(`    GET /session/all     → All session predictions\n`);

  // Begin fetching live data every 8 seconds
  startAutoRefresh(8000);
});

module.exports = app;
