// ─────────────────────────────────────────────
//  src/services/cacheService.js
//  In-memory cache with configurable TTL + auto-refresh
// ─────────────────────────────────────────────
const { getLiveMatchData } = require('./cricketService');

// ── Cache store ──
const cache = {
  liveData:  null,   // latest match data object
  fetchedAt: null,   // Date of last successful fetch
  error:     null,   // last error message (if any)
  fetching:  false,  // lock to prevent concurrent fetches
};

// ── Refresh live data from the cricket service ──
async function refreshCache() {
  if (cache.fetching) return; // already in-flight
  cache.fetching = true;

  try {
    const data = await getLiveMatchData();
    if (data) {
      cache.liveData  = data;
      cache.fetchedAt = new Date();
      cache.error     = null;
      console.log(
        `[Cache] Updated at ${cache.fetchedAt.toLocaleTimeString()} — ` +
        `${data.team1} vs ${data.team2} · ${data.score} (${data.overs} ov) ` +
        `[source: ${data.source}]`
      );
    }
  } catch (err) {
    cache.error = err.message;
    console.error('[Cache] Refresh failed:', err.message);
  } finally {
    cache.fetching = false;
  }
}

// ── Start the auto-refresh loop ──
function startAutoRefresh(intervalMs = 8000) {
  // Fetch immediately on startup
  refreshCache();

  // Then on interval
  setInterval(refreshCache, intervalMs);
  console.log(`[Cache] Auto-refresh every ${intervalMs / 1000}s started`);
}

// ── Read from cache (with age info) ──
function getCachedData() {
  return {
    data:      cache.liveData,
    fetchedAt: cache.fetchedAt,
    error:     cache.error,
    ageSeconds: cache.fetchedAt
      ? Math.floor((Date.now() - cache.fetchedAt.getTime()) / 1000)
      : null,
  };
}

// ── Force an immediate refresh (used by controllers if cache is stale) ──
async function forceRefresh() {
  cache.fetching = false; // unlock if stuck
  await refreshCache();
  return getCachedData();
}

module.exports = { startAutoRefresh, getCachedData, forceRefresh, refreshCache };
