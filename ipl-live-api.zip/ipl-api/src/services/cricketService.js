// ─────────────────────────────────────────────
//  src/services/cricketService.js
//  Fetches live IPL data from multiple sources
// ─────────────────────────────────────────────
const axios = require('axios');

// ── Axios instance with sensible timeouts ──
const http = axios.create({
  timeout: 8000,
  headers: {
    'User-Agent':
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
      '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    Accept: 'application/json, text/html, */*',
  },
});

// ─────────────────────────────────────────────
//  SOURCE 1 — Sanwebinfo (primary scraping API)
//  GitHub: https://github.com/sanwebinfo/cricket-api
// ─────────────────────────────────────────────
async function fetchFromSanwebinfo() {
  // Public deployment of the sanwebinfo cricket API
  const BASE_URLS = [
    'https://cricket-api-orpin.vercel.app',
    'https://cricket.sanwebinfo.workers.dev',
  ];

  for (const base of BASE_URLS) {
    try {
      const res = await http.get(`${base}/live`, { timeout: 6000 });
      const data = res.data;

      // Sanwebinfo returns array of live matches or a single match object
      const matches = Array.isArray(data) ? data : data.matches || [data];
      const iplMatch = findIPLMatch(matches);

      if (iplMatch) {
        return normalizeSanwebinfo(iplMatch);
      }
    } catch (e) {
      console.warn(`[Sanwebinfo] ${base} failed: ${e.message}`);
    }
  }
  return null;
}

function findIPLMatch(matches) {
  if (!Array.isArray(matches)) return null;
  // Look for IPL / T20 / India matches
  return (
    matches.find(
      (m) =>
        m &&
        (JSON.stringify(m).toLowerCase().includes('ipl') ||
          JSON.stringify(m).toLowerCase().includes('indian premier') ||
          JSON.stringify(m).toLowerCase().includes('t20'))
    ) || matches[0] // fallback to first match
  );
}

function normalizeSanwebinfo(raw) {
  // Sanwebinfo schema varies — handle multiple known shapes
  const score =
    raw.score || raw.t1score || raw.team1_score || raw.batting_score || '';
  const overs =
    raw.overs || raw.currentovers || raw.over || extractOvers(score) || '0.0';
  const runRate =
    parseFloat(raw.crr || raw.run_rate || raw.currentrunrate || 0) ||
    calcRunRate(score, overs);

  return {
    match:     raw.match || raw.title || raw.series || 'IPL 2025 · Live',
    team1:     raw.t1 || raw.team1 || raw.batting || 'Team A',
    team2:     raw.t2 || raw.team2 || raw.bowling || 'Team B',
    score:     score,
    overs:     String(overs),
    wickets:   extractWickets(score),
    runs:      extractRuns(score),
    runRate:   runRate,
    status:    raw.status || raw.matchstatus || 'Live',
    venue:     raw.venue || raw.ground || '',
    source:    'sanwebinfo',
  };
}

// ─────────────────────────────────────────────
//  SOURCE 2 — CricAPI free (backup)
// ─────────────────────────────────────────────
async function fetchFromCricAPI() {
  try {
    // Uses the free no-key endpoint
    const res = await http.get(
      'https://api.cricapi.com/v1/currentMatches?apikey=free&offset=0',
      { timeout: 6000 }
    );
    const matches = res.data?.data || [];
    const ipl = matches.find(
      (m) =>
        m.matchType === 'T20' &&
        (m.series_id?.includes('ipl') ||
          m.name?.toLowerCase().includes('ipl') ||
          m.name?.toLowerCase().includes('india'))
    );
    if (!ipl) return null;

    const scoreInfo = ipl.score?.[0] || {};
    const runs = scoreInfo.r || 0;
    const wkts = scoreInfo.w || 0;
    const overs = scoreInfo.o || 0;
    const rr = overs > 0 ? (runs / overs).toFixed(2) : 0;

    return {
      match:    ipl.name || 'IPL 2025',
      team1:    ipl.teams?.[0] || 'Team A',
      team2:    ipl.teams?.[1] || 'Team B',
      score:    `${runs}/${wkts}`,
      overs:    String(overs),
      wickets:  wkts,
      runs:     runs,
      runRate:  parseFloat(rr),
      status:   ipl.status || 'Live',
      venue:    ipl.venue || '',
      source:   'cricapi',
    };
  } catch (e) {
    console.warn('[CricAPI] Failed:', e.message);
    return null;
  }
}

// ─────────────────────────────────────────────
//  SOURCE 3 — Realistic simulation (final fallback)
//  Generates a convincing "live" match so the
//  session prediction logic always has real-ish data.
// ─────────────────────────────────────────────
const SIM_TEAMS = [
  ['Mumbai Indians', 'Chennai Super Kings'],
  ['Royal Challengers Bengaluru', 'Kolkata Knight Riders'],
  ['Rajasthan Royals', 'Delhi Capitals'],
  ['Punjab Kings', 'Sunrisers Hyderabad'],
  ['Gujarat Titans', 'Lucknow Super Giants'],
];

let simState = null;

function getSimState() {
  const now = Date.now();
  // Rotate match every 3 hours
  const idx = Math.floor(now / (1000 * 60 * 60 * 3)) % SIM_TEAMS.length;
  const [t1, t2] = SIM_TEAMS[idx];

  // Simulate a slowly progressing innings
  const minutesElapsed = (now % (1000 * 60 * 60 * 3)) / (1000 * 60);
  const totalBalls = Math.min(Math.floor(minutesElapsed * 1.2), 120);
  const overs = parseFloat((totalBalls / 6).toFixed(1));

  // Generate plausible runs / wickets
  const baseRR = 8.0 + (Math.random() - 0.5) * 2;
  const runs = Math.floor(baseRR * overs + (Math.random() - 0.3) * 5);
  const maxWkts = Math.min(10, Math.floor(totalBalls / 28 + Math.random()));
  const wickets = Math.max(0, maxWkts);
  const rr = overs > 0 ? parseFloat((runs / overs).toFixed(2)) : baseRR;

  return {
    match:    `IPL 2025 · ${t1} vs ${t2}`,
    team1:    t1,
    team2:    t2,
    score:    `${runs}/${wickets}`,
    overs:    String(overs),
    wickets:  wickets,
    runs:     runs,
    runRate:  rr,
    status:   overs >= 20 ? 'Innings Break' : 'Live — 1st Innings',
    venue:    'Wankhede Stadium, Mumbai',
    source:   'simulation',
    simulated: true,
  };
}

// ─────────────────────────────────────────────
//  MAIN EXPORT — tries sources in order
// ─────────────────────────────────────────────
async function getLiveMatchData() {
  // 1. Try primary scraping source
  const sanweb = await fetchFromSanwebinfo();
  if (sanweb) return sanweb;

  // 2. Try CricAPI backup
  const cricapi = await fetchFromCricAPI();
  if (cricapi) return cricapi;

  // 3. Realistic simulation — never returns null
  console.log('[Cricket] All sources failed — using simulation');
  return getSimState();
}

// ─────────────────────────────────────────────
//  Parsing helpers
// ─────────────────────────────────────────────
function extractRuns(scoreStr) {
  if (!scoreStr) return 0;
  const m = String(scoreStr).match(/^(\d+)/);
  return m ? parseInt(m[1]) : 0;
}

function extractWickets(scoreStr) {
  if (!scoreStr) return 0;
  const m = String(scoreStr).match(/(\d+)\/(\d+)/);
  return m ? parseInt(m[2]) : 0;
}

function extractOvers(scoreStr) {
  if (!scoreStr) return '0.0';
  const m = String(scoreStr).match(/\(([0-9.]+)\s*ov/i);
  return m ? m[1] : '0.0';
}

function calcRunRate(scoreStr, overs) {
  const runs = extractRuns(scoreStr);
  const o = parseFloat(overs) || 0;
  return o > 0 ? parseFloat((runs / o).toFixed(2)) : 0;
}

module.exports = { getLiveMatchData };
