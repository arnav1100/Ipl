// ─────────────────────────────────────────────
//  src/services/predictionEngine.js
//  Smart session prediction logic — NO random answers.
//  Uses real match data: run rate, wickets, overs.
// ─────────────────────────────────────────────

// ─────────────────────────────────────────────
//  SESSION DEFINITIONS
//  Each session has:
//    id         — unique key
//    label      — human-readable name
//    group      — category
//    targetOver — over number the session ends at
//    line       — the runs/wickets threshold
//    unit       — 'runs' | 'wickets'
//    describe() — returns a human-readable question string
// ─────────────────────────────────────────────
const SESSION_TYPES = [
  {
    id: 'pp_50',
    label: '50 runs in Powerplay (Ov 1–6)',
    group: 'Powerplay',
    targetOver: 6,
    line: 50,
    unit: 'runs',
    describe: () => '50 runs in first 6 overs',
  },
  {
    id: 'pp_60',
    label: '60 runs in Powerplay (Ov 1–6)',
    group: 'Powerplay',
    targetOver: 6,
    line: 60,
    unit: 'runs',
    describe: () => '60 runs in first 6 overs',
  },
  {
    id: 'ov10_80',
    label: '80 runs by 10th over',
    group: 'Mid-game',
    targetOver: 10,
    line: 80,
    unit: 'runs',
    describe: () => '80 runs in 10 overs',
  },
  {
    id: 'ov10_100',
    label: '100 runs by 10th over',
    group: 'Mid-game',
    targetOver: 10,
    line: 100,
    unit: 'runs',
    describe: () => '100 runs in 10 overs',
  },
  {
    id: 'ov15_120',
    label: '120 runs by 15th over',
    group: 'Mid-game',
    targetOver: 15,
    line: 120,
    unit: 'runs',
    describe: () => '120 runs in 15 overs',
  },
  {
    id: 'ov20_160',
    label: '160 runs in the innings',
    group: 'Full Match',
    targetOver: 20,
    line: 160,
    unit: 'runs',
    describe: () => '160 total runs in innings',
  },
  {
    id: 'ov20_175',
    label: '175 runs in the innings',
    group: 'Full Match',
    targetOver: 20,
    line: 175,
    unit: 'runs',
    describe: () => '175 total runs in innings',
  },
  {
    id: 'pp_wkts_2',
    label: '2 wickets in Powerplay',
    group: 'Wickets',
    targetOver: 6,
    line: 2,
    unit: 'wickets',
    describe: () => '2+ wickets in powerplay',
  },
  {
    id: 'ov20_wkts_6',
    label: '6+ wickets in innings',
    group: 'Wickets',
    targetOver: 20,
    line: 6,
    unit: 'wickets',
    describe: () => '6 wickets in innings',
  },
  {
    id: 'ov1_runs',
    label: '8 runs in 1st over',
    group: 'Over-by-over',
    targetOver: 1,
    line: 8,
    unit: 'runs',
    describe: () => '8 runs in 1st over',
  },
  {
    id: 'death_54',
    label: '54 runs in Death Overs (16–20)',
    group: 'Death Overs',
    targetOver: 20,
    line: 54,
    unit: 'runs',
    isDeathOvers: true,
    describe: () => '54 runs in death overs (16–20)',
  },
];

// ─────────────────────────────────────────────
//  CORE PREDICTION FUNCTION
//  matchData shape:
//    runs, wickets, overs (string/number), runRate
// ─────────────────────────────────────────────
function predictSession(session, matchData) {
  const { runs, wickets, runRate, overs: oversRaw } = matchData;
  const currentOvers = parseFloat(oversRaw) || 0;

  // ── Guards ──
  if (currentOvers < 0 || runs < 0) {
    return buildResult(session, 'PENDING', 50, 'Match not started yet');
  }

  // ── Already past target over? Session is settled ──
  if (currentOvers >= session.targetOver) {
    return buildResult(
      session,
      null,
      null,
      null,
      { settled: true, currentOvers, runs, wickets }
    );
  }

  // ── Wickets prediction ──
  if (session.unit === 'wickets') {
    return predictWickets(session, { runs, wickets, currentOvers, runRate });
  }

  // ── Runs prediction ──
  return predictRuns(session, { runs, wickets, currentOvers, runRate });
}

// ─────────────────────────────────────────────
//  RUNS PREDICTION LOGIC
// ─────────────────────────────────────────────
function predictRuns(session, { runs, wickets, currentOvers, runRate }) {
  const oversRemaining = session.targetOver - currentOvers;
  const isPowerplay    = currentOvers <= 6;
  const isDeathOvers   = session.isDeathOvers || currentOvers >= 15;

  // ── If runs already exceeded the line → YES is almost certain ──
  if (runs >= session.line) {
    const confidence = Math.min(97, 90 + wickets);
    return buildResult(session, 'YES', confidence,
      `Already ${runs} runs — line ${session.line} crossed`);
  }

  // ── Calculate effective run rate to use for projection ──
  let effectiveRR = runRate > 0 ? runRate : estimateBaseRR(currentOvers, wickets);

  // ── Smart adjustments to effective RR ──
  // 1. Wicket pressure — each wicket above 2 reduces projected RR slightly
  const wicketPenalty = Math.max(0, wickets - 2) * 0.18;
  effectiveRR -= wicketPenalty;

  // 2. Powerplay boost — batting teams score aggressively in pp
  if (isPowerplay && currentOvers < 3) {
    effectiveRR += 0.4; // first 3 overs tend to be aggressive
  }

  // 3. Death overs boost — pinch hitters accelerate
  if (isDeathOvers && wickets < 7) {
    effectiveRR += 0.6;
  }

  // 4. Very high run rate → sustained aggression likely
  if (runRate > 9.5) {
    effectiveRR += 0.3;
  }

  // 5. Very low run rate → bowlers on top
  if (runRate < 6 && currentOvers > 3) {
    effectiveRR -= 0.4;
  }

  // ── Project final runs at end of target over ──
  const projectedAdditional = effectiveRR * oversRemaining;
  const projectedTotal      = runs + projectedAdditional;

  // ── How far is projected from the line? ──
  const margin = projectedTotal - session.line;
  const lineGap = Math.abs(margin);

  // ── Convert margin into a confidence score ──
  // Confidence = 50% at line, scaling out ±30% per 10 runs gap
  let rawConfidence = 50 + (margin / (session.line * 0.18)) * 30;
  rawConfidence     = Math.min(95, Math.max(30, rawConfidence));

  // ── Wicket uncertainty — more wickets = more uncertainty ──
  const wicketUncertainty = Math.max(0, wickets - 3) * 2;
  rawConfidence = Math.max(30, rawConfidence - wicketUncertainty);

  // ── Time-based confidence boost (less time remaining = more certain) ──
  const oversElapsedFraction = currentOvers / session.targetOver;
  const certaintyBoost       = oversElapsedFraction * 12;
  rawConfidence              += certaintyBoost;
  rawConfidence              = Math.min(96, Math.max(28, rawConfidence));

  const prediction = projectedTotal >= session.line ? 'YES' : 'NO';
  const confidence = Math.round(rawConfidence);

  const reason = buildReason({
    runs, wickets, currentOvers, runRate: effectiveRR,
    projectedTotal: Math.round(projectedTotal),
    session, prediction
  });

  return buildResult(session, prediction, confidence, reason);
}

// ─────────────────────────────────────────────
//  WICKETS PREDICTION LOGIC
// ─────────────────────────────────────────────
function predictWickets(session, { runs, wickets, currentOvers, runRate }) {
  const oversRemaining = session.targetOver - currentOvers;

  // Already hit the line
  if (wickets >= session.line) {
    return buildResult(session, 'YES', 95,
      `${wickets} wickets already — line ${session.line} crossed`);
  }

  // Remaining wickets needed
  const needed = session.line - wickets;

  // Base wicket fall rate: historical IPL avg ~1 wicket per 18 balls = 3 overs
  let baseWktRate = 1 / 3; // wickets per over

  // Adjust for run rate — higher run rate = more attacking = slightly more risk
  if (runRate > 9) baseWktRate += 0.08;
  if (runRate < 6) baseWktRate -= 0.08;

  // Powerplay adjustment — generally fewer wickets in pp
  if (currentOvers < 6) baseWktRate -= 0.05;

  const projectedWickets = wickets + baseWktRate * oversRemaining;
  const margin           = projectedWickets - session.line;

  let rawConfidence = 50 + (margin / session.line) * 35;
  rawConfidence     = Math.min(93, Math.max(30, rawConfidence));

  const oversElapsedFraction = currentOvers / session.targetOver;
  rawConfidence += oversElapsedFraction * 10;
  rawConfidence  = Math.min(94, Math.round(rawConfidence));

  const prediction = projectedWickets >= session.line ? 'YES' : 'NO';

  return buildResult(
    session,
    prediction,
    rawConfidence,
    `${wickets} wickets now · ${needed} more needed in ${oversRemaining.toFixed(1)} overs`
  );
}

// ─────────────────────────────────────────────
//  HELPERS
// ─────────────────────────────────────────────

// Estimate a reasonable base run rate when live RR is not available
function estimateBaseRR(overs, wickets) {
  if (overs < 6)  return wickets < 2 ? 8.5 : 7.2;
  if (overs < 10) return wickets < 3 ? 8.0 : 7.0;
  if (overs < 16) return wickets < 5 ? 8.2 : 7.0;
  return wickets < 7 ? 9.5 : 8.0; // death overs
}

function buildReason({ runs, wickets, currentOvers, runRate, projectedTotal, session, prediction }) {
  const arrow = prediction === 'YES' ? '↑' : '↓';
  return (
    `${runs}/${wickets} in ${currentOvers} ov · ` +
    `RR ${runRate.toFixed(2)} · ` +
    `Projected ~${projectedTotal} vs line ${session.line} ${arrow}`
  );
}

function buildResult(session, prediction, confidence, reason, extra = {}) {
  return {
    id:          session.id,
    session:     session.describe(),
    label:       session.label,
    group:       session.group,
    line:        session.line,
    unit:        session.unit,
    prediction:  prediction,
    confidence:  confidence !== null ? `${confidence}%` : null,
    confidenceNum: confidence,
    reason:      reason,
    targetOver:  session.targetOver,
    ...extra,
  };
}

// ─────────────────────────────────────────────
//  PUBLIC API
// ─────────────────────────────────────────────

// Predict a single session by id
function predictOne(sessionId, matchData) {
  const session = SESSION_TYPES.find((s) => s.id === sessionId);
  if (!session) return { error: `Unknown session id: ${sessionId}` };
  return predictSession(session, matchData);
}

// Predict all sessions
function predictAll(matchData) {
  return SESSION_TYPES.map((s) => predictSession(s, matchData));
}

// Get list of available session ids + labels
function getSessionList() {
  return SESSION_TYPES.map((s) => ({
    id:    s.id,
    label: s.label,
    group: s.group,
    line:  s.line,
    unit:  s.unit,
  }));
}

module.exports = { predictOne, predictAll, getSessionList, SESSION_TYPES };
